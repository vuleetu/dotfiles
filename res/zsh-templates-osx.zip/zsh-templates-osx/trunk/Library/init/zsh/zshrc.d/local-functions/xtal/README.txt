This directory contains functions and completion functions for
biophysics and X-ray crystallographic programs.  Unless you
make use of one or more of these programs, you can safely ignore
or delete this directory and its contents.  It is not read by
default, but is read if the presence of one of the major programs
is detected, or you change the default setting in $ZDOT/functions.local

