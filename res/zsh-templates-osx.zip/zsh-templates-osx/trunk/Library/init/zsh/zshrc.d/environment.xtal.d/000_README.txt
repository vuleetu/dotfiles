Rather than alter files in this directory, I recommend doing the following:


   cd $ZDOT/zshrc_local.d

   ln -s ../zshrc.d/environment.xtal.d/phenix_env.zsh-disabled     phenix_env.zsh

rather than alter anything the distributed $ZDOT/zshrc.d  directory.