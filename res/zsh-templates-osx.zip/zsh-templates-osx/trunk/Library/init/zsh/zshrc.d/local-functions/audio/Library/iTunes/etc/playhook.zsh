#!/bin/zsh -f
 /Library/iTunes/etc/nyquist.zsh &
 return 0

