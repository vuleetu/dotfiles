#!/bin/zsh -f

 true
 return 0

